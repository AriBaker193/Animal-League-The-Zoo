'use strict';
// Minimal authoritative-host room relay and static game server.
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const {WebSocketServer,WebSocket}=require('ws');
const PORT=Number(process.env.PORT||3000);
const root=__dirname;
const mime={'.html':'text/html; charset=utf-8','.png':'image/png','.js':'application/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json'};
const staticFiles=new Set(['index.html','home_artwork.png','apple-touch-icon.png','icon-192.png','icon-512.png']);
const server=http.createServer((req,res)=>{
 const url=new URL(req.url,'http://localhost');
 const filename=url.pathname==='/'?'index.html':url.pathname.slice(1);
 if(!staticFiles.has(filename)){res.writeHead(404);res.end('Not found');return}
 const filepath=path.join(root,filename);
 fs.readFile(filepath,(error,data)=>{if(error){res.writeHead(404);res.end('Not found');return}res.writeHead(200,{'Content-Type':mime[path.extname(filepath)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(data)});
});
const wss=new WebSocketServer({server,path:'/ws',maxPayload:96*1024});
const rooms=new Map();
const CODE_CHARS='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function roomCode(){let code;do{code=Array.from({length:6},()=>CODE_CHARS[Math.floor(Math.random()*CODE_CHARS.length)]).join('')}while(rooms.has(code));return code}
const send=(ws,obj)=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj))};
function leave(ws){const room=ws.room;if(!room)return;ws.room=null;if(ws===room.host){send(room.guest,{type:'peer',connected:false});if(room.guest){room.guest.room=null;room.guest.close(4001,'Host left')}rooms.delete(room.code)}else if(ws===room.guest){room.guest=null;send(room.host,{type:'peer',connected:false})}}
wss.on('connection',ws=>{
 ws.on('message',data=>{let m;try{m=JSON.parse(String(data))}catch{return}
  if(!m||typeof m.type!=='string')return;
  if(m.type==='create'){leave(ws);const code=roomCode();const room={code,host:ws,guest:null};rooms.set(code,room);ws.room=room;send(ws,{type:'created',code});return}
  if(m.type==='join'){leave(ws);const code=String(m.code||'').trim().toUpperCase();const room=rooms.get(code);if(!room||!room.host||room.guest){send(ws,{type:'error',message:'Room missing or full. Ask host for a new code.'});return}room.guest=ws;ws.room=room;send(ws,{type:'joined',code});send(room.host,{type:'peer',connected:true});send(ws,{type:'peer',connected:true});return}
  const room=ws.room;if(!room||!room.guest)return;
  if(m.type==='start'&&ws===room.host&&m.config&&Number.isInteger(m.config.away)&&Number.isInteger(m.config.home)){send(room.guest,{type:'start',config:{away:m.config.away,home:m.config.home,innings:Math.max(1,Math.min(9,Number(m.config.innings)||3))}});return}
  if(m.type==='input'&&ws===room.guest&&m.input&&typeof m.input.type==='string'){send(room.host,{type:'input',input:m.input});return}
  if(m.type==='snapshot'&&ws===room.host&&m.data){send(room.guest,{type:'snapshot',data:m.data});return}
 });
 ws.on('close',()=>leave(ws));ws.on('error',()=>leave(ws));
});
server.listen(PORT,()=>console.log(`Animal League online server listening at http://localhost:${PORT}`));
