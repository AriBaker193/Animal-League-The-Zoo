# Animal League: The Zoo - V70 Online Play (Beta)

Online mode requires a publicly reachable Node.js server. A static HTML file or Netlify static ZIP cannot provide matchmaking on its own.

1. Upload this folder as a Node.js web service (for example, Render or Railway, with `npm install` and `npm start`). Use Node.js 20 or newer and ensure WebSockets are supported.
2. The hosting service must set `PORT` as needed. Set the start command to `npm start`.
3. Open the service HTTPS address on each player's browser or iPad. Both players **must** open the same deployed URL.
4. Both choose `Online friends - offense + defense`. Player 1 selects teams and clicks `CREATE ROOM`; share the six-letter room code. Player 2 enters that code and clicks `JOIN`.
5. When Player 2 has joined, Player 1 clicks `PLAY BALL`.
6. Player 1 is away; Player 2 is home. Each player bats and fields/pitches on their appropriate half of each inning.

This is a **beta implementation**. The host browser is authoritative for ball and runner decisions and must stay open. The guest receives snapshots of game state. Network latency can affect swing timing and fielding accuracy, and automatic host migration/reconnection isn't implemented. This version is not yet production-quality real-time multiplayer. Players must deploy the included service; simply uploading the ZIP to a static host won't enable online play.

The offline single-player and local two-player modes continue to run from the static HTML file without the server.
